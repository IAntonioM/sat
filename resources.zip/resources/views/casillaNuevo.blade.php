@extends('layouts.cabecera')
@section('content')
    <style>
        .table> :not(caption)>*>* {
            padding: 0.75rem 0.2rem;
        }
    </style>
    <div class="card " style="background-image: url(assets/media/logos/fondo1.jpg);background-position: center center;">
        <div class="card-body pt-9 pb-0">
            <!--begin::Details-->
            <div class="d-flex flex-wrap flex-sm-nowrap mb-6">
                <!--begin::Image-->
                <!--<div class="d-flex flex-center flex-shrink-0 bg-light rounded w-100px h-100px w-lg-150px h-lg-150px me-7 mb-4">
                        <img class="mw-50px mw-lg-75px" src="assets/media/svg/brand-logos/volicity-9.svg" alt="image" />
                    </div>-->
                <!--end::Image-->
                <!--begin::Wrapper-->
                <div class="flex-grow-1">
                    <!--begin::Head-->
                    <div class="d-flex justify-content-between align-items-start flex-wrap mb-2">
                        <!--begin::Details-->
                        <div class="d-flex flex-column">
                            <!--begin::Status-->
                            <div class="d-flex align-items-center mb-1">
                                <span class="text-gray-800 text-primary fs-1 fw-bold me-3">Casilla Electrónica</span>
                                <!--<span class="badge badge-light-success me-auto">In Progress</span>-->
                            </div>
                            <!--end::Status-->
                            <!--begin::Description-->
                            <div class="d-flex flex-wrap fw-semibold mb-4 fs-5 text-gray-400">
                                Actualizado al {{ \Carbon\Carbon::now()->format('d/m/Y') }}</div>
                            <!--end::Description-->
                        </div>
                        <!--
                            <div class="d-flex mb-4">
                                <div class="border border-gray-300 border-dashed rounded min-w-125px py-3 px-4 me-6 mb-3 badge-light-primary">
                                    <div class="fw-semibold fs-6 text-gray-400">Su Deuda Actual es:</div>
                                    <div class="d-flex align-items-center">
                                        <div class=" fw-bold" data-kt-countup="true" data-kt-countup-value="15000" data-kt-countup-prefix="S/." style="font-size:30px">0</div>
                                    </div>
                                </div>
                            </div>
                            -->
                    </div>
                    <!--end::Head-->

                </div>
            </div>
        </div>
    </div>
    <div id="kt_content_container" class="d-flex flex-column-fluid align-items-start "
        style="padding-right: calc(0px * .5); padding-left: calc(0px * .5);">
        <!--begin::Post-->
        <div class="content flex-row-fluid" id="kt_content">
            <!--begin::Products-->
            <div class="card card-flush">
                <!--begin::Card header-->

                <!--end::Card header-->
                <!--begin::Card body-->
                <div class="card-body pt-0">
                    <!--begin::Table-->
                    <div class="d-flex flex-column flex-lg-row">
                        <div class="d-none d-lg-flex flex-column flex-lg-row-auto w-100 w-lg-300px" data-kt-drawer="true"
                            data-kt-drawer-name="inbox-aside" data-kt-drawer-activate="{default: true, lg: false}"
                            data-kt-drawer-overlay="true" data-kt-drawer-width="225px" data-kt-drawer-direction="start"
                            data-kt-drawer-toggle="#kt_inbox_aside_toggle"style="background-color: #f9f9f9;">
                            <!--begin::Sticky aside-->
                            <div class="card card-flush mb-0" data-kt-sticky="false"
                                data-kt-sticky-name="inbox-aside-sticky"
                                data-kt-sticky-offset="{default: false, xl: '100px'}" data-kt-sticky-width="{lg: '275px'}"
                                data-kt-sticky-left="auto" data-kt-sticky-top="100px" data-kt-sticky-animation="false"
                                data-kt-sticky-zindex="95">
                                <!--begin::Aside content-->
                                <div class="card-body" style="background-color: #f9f9f9;">
                                    <!--begin::Button-->
                                    <a href="{{ route('createCasilla') }}" class="btn btn-primary fw-bold w-100 mb-8">Nuevo
                                        Mensaje</a>

                                    <!--end::Button-->
                                    <!--begin::Menu-->
                                    <div
                                        class="menu menu-column menu-rounded menu-state-bg menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary mb-10">
                                        <!--begin::Menu item-->
                                        <div class="menu-item mb-3">
                                            <!--begin::Inbox-->
                                            <a href="{{ route('casilla') }}" class="menu-link active">
                                                <span class="menu-icon">
                                                    <i class="ki-duotone ki-sms fs-2 me-3">
                                                        <span class="path1"></span>
                                                        <span class="path2"></span>
                                                    </i>
                                                </span>
                                                <span class="menu-title fw-bold">Buzón de Notificaciones</span>
                                                <span class="badge badge-light-success">3</span>
                                            </a>
                                            <!--end::Inbox-->
                                        </div>

                                        <!--end::Menu item-->
                                        <!--begin::Menu item-->
                                        <div class="menu-item mb-3">
                                            <!--begin::Marked-->
                                            <span class="menu-link">
                                                <span class="menu-icon">
                                                    <i class="ki-duotone ki-abstract-23 fs-2 me-3">
                                                        <span class="path1"></span>
                                                        <span class="path2"></span>
                                                    </i>
                                                </span>
                                                <span class="menu-title fw-bold">Valores Tributarios</span>
                                                <span class="badge badge-light-primary">6</span>
                                            </span>
                                            <!--end::Marked-->
                                        </div>
                                        <!--end::Menu item-->
                                        <!--begin::Menu item-->
                                        <div class="menu-item mb-3">
                                            <!--begin::Draft-->
                                            <span class="menu-link">
                                                <span class="menu-icon">
                                                    <i class="ki-duotone ki-file fs-2 me-3">
                                                        <span class="path1"></span>
                                                        <span class="path2"></span>
                                                    </i>
                                                </span>
                                                <span class="menu-title fw-bold">Órdenes de Pago</span>
                                                <span class="badge badge-light-warning">5</span>
                                            </span>
                                            <!--end::Draft-->
                                        </div>
                                        <!--end::Menu item-->
                                        <!--begin::Menu item-->
                                        <div class="menu-item mb-3">
                                            <!--begin::Sent-->
                                            <span class="menu-link">
                                                <span class="menu-icon">
                                                    <i class="ki-duotone ki-send fs-2 me-3">
                                                        <span class="path1"></span>
                                                        <span class="path2"></span>
                                                    </i>
                                                </span>
                                                <span class="menu-title fw-bold">Resoluciones de Determinación</span>
                                                <span class="badge badge-light-info">6</span>
                                            </span>
                                            <!--end::Sent-->
                                        </div>
                                        <!--end::Menu item-->
                                        <!--begin::Menu item-->
                                        <div class="menu-item">
                                            <!--begin::Trash-->
                                            <span class="menu-link">
                                                <span class="menu-icon">
                                                    <i class="ki-duotone ki-trash fs-2 me-3">
                                                        <span class="path1"></span>
                                                        <span class="path2"></span>
                                                        <span class="path3"></span>
                                                        <span class="path4"></span>
                                                        <span class="path5"></span>
                                                    </i>
                                                </span>
                                                <span class="menu-title fw-bold">Documentos en Instancia Coactiva</span>
                                                <span class="badge badge-light-danger">6</span>
                                            </span>
                                            <!--end::Trash-->
                                        </div>
                                        <!--end::Menu item-->
                                    </div>
                                    <!--end::Menu-->
                                    <!--begin::Menu-->

                                    <!--end::Menu-->
                                </div>
                                <!--end::Aside content-->
                            </div>
                            <!--end::Sticky aside-->
                        </div>
                        <div class="flex-lg-row-fluid ms-lg-7 ms-xl-10">
                            <!--begin::Card-->
                            <div class="card">
                                <div class="card-header d-flex align-items-center justify-content-between py-3">
                                    <h2 class="card-title m-0">Nuevo Mensaje</h2>
                                    <!--begin::Toggle-->
                                    <a href="#"
                                        class="btn btn-sm btn-icon btn-color-primary btn-light btn-active-light-primary d-lg-none"
                                        data-bs-toggle="tooltip" data-bs-dismiss="click" data-bs-placement="top"
                                        title="Toggle inbox menu" id="kt_inbox_aside_toggle">
                                        <i class="ki-duotone ki-burger-menu-2 fs-3 m-0">
                                            <span class="path1"></span>
                                            <span class="path2"></span>
                                            <span class="path3"></span>
                                            <span class="path4"></span>
                                            <span class="path5"></span>
                                            <span class="path6"></span>
                                            <span class="path7"></span>
                                            <span class="path8"></span>
                                            <span class="path9"></span>
                                            <span class="path10"></span>
                                        </i>
                                    </a>
                                    <!--end::Toggle-->
                                </div>
                                <div class="card-body p-0">
                                    <!--begin::Form-->
                                    <livewire:nueva-casilla.nueva-casilla-component />
                                    {{-- <form id="kt_inbox_compose_form">
                                        <!--begin::Body-->
                                        <div class="d-block">
                                            <!--begin::To-->
                                            <div class="d-flex align-items-center border-bottom px-8 min-h-50px">
                                                <!--begin::Label-->
                                                <div class="text-dark fw-bold w-75px">Para:</div>
                                                <!--end::Label-->
                                                <!--begin::Input-->
                                                <input type="text"
                                                    class="form-control form-control-transparent border-0"
                                                    name="compose_to" value="" data-kt-inbox-form="tagify" />
                                                <!--end::Input-->
                                                <!--begin::CC & BCC buttons-->
                                                <div class="ms-auto w-75px text-end">
                                                    <span class="text-muted fs-bold cursor-pointer text-hover-primary me-2"
                                                        data-kt-inbox-form="cc_button">Cc</span>
                                                    <span class="text-muted fs-bold cursor-pointer text-hover-primary"
                                                        data-kt-inbox-form="bcc_button">Bcc</span>
                                                </div>
                                                <!--end::CC & BCC buttons-->
                                            </div>
                                            <!--end::To-->
                                            <!--begin::CC-->
                                            <div class="d-none align-items-center border-bottom ps-8 pe-5 min-h-50px"
                                                data-kt-inbox-form="cc">
                                                <!--begin::Label-->
                                                <div class="text-dark fw-bold w-75px">Cc:</div>
                                                <!--end::Label-->
                                                <!--begin::Input-->
                                                <input type="text"
                                                    class="form-control form-control-transparent border-0"
                                                    name="compose_cc" value="" data-kt-inbox-form="tagify" />
                                                <!--end::Input-->
                                                <!--begin::Close-->
                                                <span class="btn btn-clean btn-xs btn-icon" data-kt-inbox-form="cc_close">
                                                    <i class="ki-duotone ki-cross fs-5">
                                                        <span class="path1"></span>
                                                        <span class="path2"></span>
                                                    </i>
                                                </span>
                                                <!--end::Close-->
                                            </div>
                                            <!--end::CC-->
                                            <!--begin::BCC-->
                                            <div class="d-none align-items-center border-bottom inbox-to-bcc ps-8 pe-5 min-h-50px"
                                                data-kt-inbox-form="bcc">
                                                <!--begin::Label-->
                                                <div class="text-dark fw-bold w-75px">Bcc:</div>
                                                <!--end::Label-->
                                                <!--begin::Input-->
                                                <input type="text"
                                                    class="form-control form-control-transparent border-0"
                                                    name="compose_bcc" value="" data-kt-inbox-form="tagify" />
                                                <!--end::Input-->
                                                <!--begin::Close-->
                                                <span class="btn btn-clean btn-xs btn-icon"
                                                    data-kt-inbox-form="bcc_close">
                                                    <i class="ki-duotone ki-cross fs-5">
                                                        <span class="path1"></span>
                                                        <span class="path2"></span>
                                                    </i>
                                                </span>
                                                <!--end::Close-->
                                            </div>
                                            <!--end::BCC-->
                                            <!--begin::Subject-->
                                            <div class="border-bottom">
                                                <input
                                                    class="form-control form-control-transparent border-0 px-8 min-h-45px"
                                                    name="compose_subject" placeholder="Asunto" />
                                            </div>
                                            <!--end::Subject-->
                                            <!--begin::Message-->
                                            <div id="kt_inbox_form_editor" class="bg-transparent border-0 h-350px px-3">
                                            </div>
                                            <!--end::Message-->
                                            <!--begin::Attachments-->
                                            <div class="dropzone dropzone-queue px-8 py-4" id="kt_inbox_reply_attachments"
                                                data-kt-inbox-form="dropzone">
                                                <div class="dropzone-items">
                                                    <div class="dropzone-item" style="display:none">
                                                        <!--begin::Dropzone filename-->
                                                        <div class="dropzone-file">
                                                            <div class="dropzone-filename"
                                                                title="some_image_file_name.jpg">
                                                                <span data-dz-name="">some_image_file_name.jpg</span>
                                                                <strong>(
                                                                    <span data-dz-size="">340kb</span>)</strong>
                                                            </div>
                                                            <div class="dropzone-error" data-dz-errormessage=""></div>
                                                        </div>
                                                        <!--end::Dropzone filename-->
                                                        <!--begin::Dropzone progress-->
                                                        <div class="dropzone-progress">
                                                            <div class="progress bg-gray-300">
                                                                <div class="progress-bar bg-primary" role="progressbar"
                                                                    aria-valuemin="0" aria-valuemax="100"
                                                                    aria-valuenow="0" data-dz-uploadprogress=""></div>
                                                            </div>
                                                        </div>
                                                        <!--end::Dropzone progress-->
                                                        <!--begin::Dropzone toolbar-->
                                                        <div class="dropzone-toolbar">
                                                            <span class="dropzone-delete" data-dz-remove="">
                                                                <i class="ki-duotone ki-cross fs-2">
                                                                    <span class="path1"></span>
                                                                    <span class="path2"></span>
                                                                </i>
                                                            </span>
                                                        </div>
                                                        <!--end::Dropzone toolbar-->
                                                    </div>
                                                </div>
                                            </div>
                                            <!--end::Attachments-->
                                        </div>
                                        <!--end::Body-->
                                        <!--begin::Footer-->
                                        <div class="d-flex flex-stack flex-wrap gap-2 py-5 ps-8 pe-5 border-top">
                                            <!--begin::Actions-->
                                            <div class="d-flex align-items-center me-3">
                                                <!--begin::Send-->
                                                <div class="btn-group me-4">
                                                    <!--begin::Submit-->
                                                    <span class="btn btn-primary fs-bold px-6" data-kt-inbox-form="send">
                                                        <span class="indicator-label">Enviar</span>
                                                        <span class="indicator-progress">Espere por favor...
                                                            <span
                                                                class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                                    </span>
                                                    <!--end::Submit-->
                                                    <!--begin::Send options-->

                                                    <!--end::Send options-->
                                                </div>
                                                <!--end::Send-->
                                                <!--begin::Upload attachement-->
                                                <span class="btn btn-icon btn-sm btn-clean btn-active-light-primary me-2"
                                                    id="kt_inbox_reply_attachments_select"
                                                    data-kt-inbox-form="dropzone_upload">
                                                    <i class="ki-duotone ki-paper-clip fs-2 m-0"></i>
                                                </span>
                                                <!--end::Upload attachement-->
                                                <!--begin::Pin-->
                                                <span class="btn btn-icon btn-sm btn-clean btn-active-light-primary">
                                                    <i class="ki-duotone ki-geolocation fs-2 m-0">
                                                        <span class="path1"></span>
                                                        <span class="path2"></span>
                                                    </i>
                                                </span>
                                                <!--end::Pin-->
                                            </div>
                                            <!--end::Actions-->
                                            <!--begin::Toolbar-->
                                            <div class="d-flex align-items-center">
                                                <!--begin::More actions-->
                                                <span class="btn btn-icon btn-sm btn-clean btn-active-light-primary me-2"
                                                    data-toggle="tooltip" title="More actions">
                                                    <i class="ki-duotone ki-setting-2 fs-2">
                                                        <span class="path1"></span>
                                                        <span class="path2"></span>
                                                    </i>
                                                </span>
                                                <!--end::More actions-->
                                                <!--begin::Dismiss reply-->
                                                <span class="btn btn-icon btn-sm btn-clean btn-active-light-primary"
                                                    data-inbox="dismiss" data-toggle="tooltip" title="Dismiss reply">
                                                    <i class="ki-duotone ki-trash fs-2">
                                                        <span class="path1"></span>
                                                        <span class="path2"></span>
                                                        <span class="path3"></span>
                                                        <span class="path4"></span>
                                                        <span class="path5"></span>
                                                    </i>
                                                </span>
                                                <!--end::Dismiss reply-->
                                            </div>
                                            <!--end::Toolbar-->
                                        </div>
                                        <!--end::Footer-->
                                    </form> --}}
                                    <!--end::Form-->
                                </div>
                            </div>
                            <!--end::Card-->
                        </div>
                    </div>



                    <!--end::Table-->
                </div>
                <!--end::Card body-->
            </div>
            <!--end::Products-->
        </div>
        <!--end::Post-->
    </div>
@endsection
