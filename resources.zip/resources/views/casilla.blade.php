@extends('layouts.cabecera')
@section('content')
    <style>
        .table> :not(caption)>*>* {
            padding: 0.75rem 0.2rem;
        }
    </style>


    <div class="card " style="background-image: url(assets/media/logos/fondo1.jpg);background-position: center center;">
        <div class="card-body pt-9 pb-0">
            <!--begin::Details-->
            <div class="d-flex flex-wrap flex-sm-nowrap mb-6">
                <!--begin::Image-->
                <!--<div class="d-flex flex-center flex-shrink-0 bg-light rounded w-100px h-100px w-lg-150px h-lg-150px me-7 mb-4">
                        <img class="mw-50px mw-lg-75px" src="assets/media/svg/brand-logos/volicity-9.svg" alt="image" />
                    </div>-->
                <!--end::Image-->
                <!--begin::Wrapper-->
                <div class="flex-grow-1">
                    <!--begin::Head-->
                    <div class="d-flex justify-content-between align-items-start flex-wrap mb-2">
                        <!--begin::Details-->
                        <div class="d-flex flex-column">
                            <!--begin::Status-->
                            <div class="d-flex align-items-center mb-1">
                                <span class="text-gray-800 text-primary fs-1 fw-bold me-3">Casilla Electrónica</span>
                                <!--<span class="badge badge-light-success me-auto">In Progress</span>-->
                            </div>
                            <!--end::Status-->
                            <!--begin::Description-->
                            <div class="d-flex flex-wrap fw-semibold mb-4 fs-5 text-gray-400">
                                Actualizado al {{ \Carbon\Carbon::now()->format('d/m/Y') }}</div>
                            <!--end::Description-->
                        </div>

                        <!--
                            <div class="d-flex mb-4">
                                <div class="border border-gray-300 border-dashed rounded min-w-125px py-3 px-4 me-6 mb-3 badge-light-primary">
                                    <div class="fw-semibold fs-6 text-gray-400">Su Deuda Actual es:</div>
                                    <div class="d-flex align-items-center">
                                        <div class=" fw-bold" data-kt-countup="true" data-kt-countup-value="15000" data-kt-countup-prefix="S/." style="font-size:30px">0</div>
                                    </div>
                                </div>
                            </div>
                            -->
                    </div>
                    <!--end::Head-->

                </div>
            </div>
        </div>
    </div>
    <div id="kt_content_container" class="d-flex flex-column-fluid align-items-start "
        style="padding-right: calc(0px * .5); padding-left: calc(0px * .5);">
        <!--begin::Post-->
        <div class="content flex-row-fluid" id="kt_content">
            <!--begin::Products-->
            <div class="card card-flush">
                <!--begin::Card header-->

                <!--end::Card header-->
                <!--begin::Card body-->
                <div class="card-body pt-0">
                    <!--begin::Table-->
                    <div class="d-flex flex-column flex-lg-row">

                        <livewire:menu-casilla.menu-casilla-component />
                        <livewire:recibido.recibido-component />
                        {{-- <div class=" col-xl-3 row" style="margin: 0 1rem; border-left: 1px solid #c7c7c9;">
									<!--begin::Card-->
									<div class="card">
										<div class="card-header align-items-center py-5 gap-2 gap-md-5" style="padding: 0 1rem;">
											<!--begin::Actions-->
											<div class="d-flex flex-wrap gap-2">
												<!--begin::Checkbox-->
												<div class="form-check form-check-sm form-check-custom form-check-solid " >
													<input class="form-check-input" type="checkbox" data-kt-check="true" data-kt-check-target="#kt_inbox_listing .form-check-input" value="1" />
												</div>


                                                <div class="d-flex align-items-center position-relative">
													<i class="ki-duotone ki-magnifier fs-3 position-absolute ms-4">
														<span class="path1"></span>
														<span class="path2"></span>
													</i>
													<input type="text" data-kt-inbox-listing-filter="search" class="form-control form-control-sm form-control-solid mw-120 min-w-120px min-w-lg-150px  ps-11" placeholder="Buscar por asunto" />
												</div>



												<!--end::Sort-->
											</div>
											<!--end::Actions-->
											<!--begin::Actions-->

											<!--end::Actions-->
										</div>
										<div class="card-body p-0">
											<!--begin::Table-->
											<table class="table table-hover table-row-dashed fs-6 gy-5 my-0" id="kt_inbox_listing" style="padding: 0rem 0rem;">
												<thead class="d-none">
													<tr>
														<th>Checkbox</th>
														<th>Actions</th>
														<th>Author</th>
														<th>Title</th>
														<th>Date</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td class="ps-4">
															<div class="form-check form-check-sm form-check-custom form-check-solid mt-3">
																<input class="form-check-input" type="checkbox" value="1" />
															</div>
														</td>
														<td>
															<div class="text-dark gap-1 pt-2">
																<!--begin::Heading-->

																<a href="" class="text-primary" style="padding: 0 10px 0 0 ">
																	<span class="fw-bold">Digital PPV Customer Confirmation</span>

																    <br><span class="fw-semibold text-dark" style="font-size: 12px">15/04/2015 15:02:45</span>

                                                                </a><br>

                                                                <div style="text-align: right">
                                                                    <a href="#" class="btn btn-sm btn-icon btn-light-warning " data-bs-toggle="tooltip" data-bs-dismiss="click" data-bs-placement="top" title="Archivar">
                                                                        <i class="ki-duotone ki-sms fs-2">
                                                                            <span class="path1"></span>
                                                                            <span class="path2"></span>
                                                                        </i>
                                                                    </a>
                                                                    <!--end::Archive-->
                                                                    <!--begin::Delete-->
                                                                    <a href="#" class="btn btn-sm btn-icon btn-light-danger " data-bs-toggle="tooltip" data-bs-dismiss="click" data-bs-placement="top" title="Eliminar">
                                                                        <i class="ki-duotone ki-trash fs-2">
                                                                            <span class="path1"></span>
                                                                            <span class="path2"></span>
                                                                            <span class="path3"></span>
                                                                            <span class="path4"></span>
                                                                            <span class="path5"></span>
                                                                        </i>
                                                                    </a>
                                                                </div>

																<!--end::Heading-->
															</div>
															<!--begin::Badges-->

															<!--end::Badges-->
														</td>

													</tr>
													<tr>
														<td class="ps-4">
															<div class="form-check form-check-sm form-check-custom form-check-solid mt-3">
																<input class="form-check-input" type="checkbox" value="1" />
															</div>
														</td>
														<td>
															<div class="text-dark gap-1 pt-2">
																<!--begin::Heading-->

																<a href="" class="text-primary" style="padding: 0 10px 0 0 ">
																	<span class="fw-bold">Digital PPV Customer Confirmation</span>

																    <br><span class="fw-semibold text-dark" style="font-size: 12px">15/04/2015 15:02:45</span>

                                                                </a><br>

                                                                <div style="text-align: right">
                                                                    <a href="#" class="btn btn-sm btn-icon btn-light-warning " data-bs-toggle="tooltip" data-bs-dismiss="click" data-bs-placement="top" title="Archivar">
                                                                        <i class="ki-duotone ki-sms fs-2">
                                                                            <span class="path1"></span>
                                                                            <span class="path2"></span>
                                                                        </i>
                                                                    </a>
                                                                    <!--end::Archive-->
                                                                    <!--begin::Delete-->
                                                                    <a href="#" class="btn btn-sm btn-icon btn-light-danger " data-bs-toggle="tooltip" data-bs-dismiss="click" data-bs-placement="top" title="Eliminar">
                                                                        <i class="ki-duotone ki-trash fs-2">
                                                                            <span class="path1"></span>
                                                                            <span class="path2"></span>
                                                                            <span class="path3"></span>
                                                                            <span class="path4"></span>
                                                                            <span class="path5"></span>
                                                                        </i>
                                                                    </a>
                                                                </div>

																<!--end::Heading-->
															</div>
															<!--begin::Badges-->

															<!--end::Badges-->
														</td>

													</tr>
                                                    <tr>
														<td class="ps-4">
															<div class="form-check form-check-sm form-check-custom form-check-solid mt-3">
																<input class="form-check-input" type="checkbox" value="1" />
															</div>
														</td>
														<td>
															<div class="text-dark gap-1 pt-2">
																<!--begin::Heading-->

																<a href="" class="text-primary" style="padding: 0 10px 0 0 ">
																	<span class="fw-bold">Digital PPV Customer Confirmation</span>

																    <br><span class="fw-semibold text-dark" style="font-size: 12px">15/04/2015 15:02:45</span>

                                                                </a><br>

                                                                <div style="text-align: right">
                                                                    <a href="#" class="btn btn-sm btn-icon btn-light-warning " data-bs-toggle="tooltip" data-bs-dismiss="click" data-bs-placement="top" title="Archivar">
                                                                        <i class="ki-duotone ki-sms fs-2">
                                                                            <span class="path1"></span>
                                                                            <span class="path2"></span>
                                                                        </i>
                                                                    </a>
                                                                    <!--end::Archive-->
                                                                    <!--begin::Delete-->
                                                                    <a href="#" class="btn btn-sm btn-icon btn-light-danger " data-bs-toggle="tooltip" data-bs-dismiss="click" data-bs-placement="top" title="Eliminar">
                                                                        <i class="ki-duotone ki-trash fs-2">
                                                                            <span class="path1"></span>
                                                                            <span class="path2"></span>
                                                                            <span class="path3"></span>
                                                                            <span class="path4"></span>
                                                                            <span class="path5"></span>
                                                                        </i>
                                                                    </a>
                                                                </div>

																<!--end::Heading-->
															</div>
															<!--begin::Badges-->

															<!--end::Badges-->
														</td>

													</tr>
                                                    <tr>
														<td class="ps-4">
															<div class="form-check form-check-sm form-check-custom form-check-solid mt-3">
																<input class="form-check-input" type="checkbox" value="1" />
															</div>
														</td>
														<td>
															<div class="text-dark gap-1 pt-2">
																<!--begin::Heading-->

																<a href="" class="text-primary" style="padding: 0 10px 0 0 ">
																	<span class="fw-bold">Digital PPV Customer Confirmation</span>

																    <br><span class="fw-semibold text-dark" style="font-size: 12px">15/04/2015 15:02:45</span>

                                                                </a><br>

                                                                <div style="text-align: right">
                                                                    <a href="#" class="btn btn-sm btn-icon btn-light-warning " data-bs-toggle="tooltip" data-bs-dismiss="click" data-bs-placement="top" title="Archivar">
                                                                        <i class="ki-duotone ki-sms fs-2">
                                                                            <span class="path1"></span>
                                                                            <span class="path2"></span>
                                                                        </i>
                                                                    </a>
                                                                    <!--end::Archive-->
                                                                    <!--begin::Delete-->
                                                                    <a href="#" class="btn btn-sm btn-icon btn-light-danger " data-bs-toggle="tooltip" data-bs-dismiss="click" data-bs-placement="top" title="Eliminar">
                                                                        <i class="ki-duotone ki-trash fs-2">
                                                                            <span class="path1"></span>
                                                                            <span class="path2"></span>
                                                                            <span class="path3"></span>
                                                                            <span class="path4"></span>
                                                                            <span class="path5"></span>
                                                                        </i>
                                                                    </a>
                                                                </div>

																<!--end::Heading-->
															</div>
															<!--begin::Badges-->

															<!--end::Badges-->
														</td>

													</tr>
                                                    <tr>
														<td class="ps-4">
															<div class="form-check form-check-sm form-check-custom form-check-solid mt-3">
																<input class="form-check-input" type="checkbox" value="1" />
															</div>
														</td>
														<td>
															<div class="text-dark gap-1 pt-2">
																<!--begin::Heading-->

																<a href="" class="text-primary" style="padding: 0 10px 0 0 ">
																	<span class="fw-bold">Digital PPV Customer Confirmation</span>

																    <br><span class="fw-semibold text-dark" style="font-size: 12px">15/04/2015 15:02:45</span>

                                                                </a><br>

                                                                <div style="text-align: right">
                                                                    <a href="#" class="btn btn-sm btn-icon btn-light-warning " data-bs-toggle="tooltip" data-bs-dismiss="click" data-bs-placement="top" title="Archivar">
                                                                        <i class="ki-duotone ki-sms fs-2">
                                                                            <span class="path1"></span>
                                                                            <span class="path2"></span>
                                                                        </i>
                                                                    </a>
                                                                    <!--end::Archive-->
                                                                    <!--begin::Delete-->
                                                                    <a href="#" class="btn btn-sm btn-icon btn-light-danger " data-bs-toggle="tooltip" data-bs-dismiss="click" data-bs-placement="top" title="Eliminar">
                                                                        <i class="ki-duotone ki-trash fs-2">
                                                                            <span class="path1"></span>
                                                                            <span class="path2"></span>
                                                                            <span class="path3"></span>
                                                                            <span class="path4"></span>
                                                                            <span class="path5"></span>
                                                                        </i>
                                                                    </a>
                                                                </div>

																<!--end::Heading-->
															</div>
															<!--begin::Badges-->

															<!--end::Badges-->
														</td>

													</tr>
                                                    <tr>
														<td class="ps-4">
															<div class="form-check form-check-sm form-check-custom form-check-solid mt-3">
																<input class="form-check-input" type="checkbox" value="1" />
															</div>
														</td>
														<td>
															<div class="text-dark gap-1 pt-2">
																<!--begin::Heading-->

																<a href="" class="text-primary" style="padding: 0 10px 0 0 ">
																	<span class="fw-bold">Digital PPV Customer Confirmation</span>

																    <br><span class="fw-semibold text-dark" style="font-size: 12px">15/04/2015 15:02:45</span>

                                                                </a><br>

                                                                <div style="text-align: right">
                                                                    <a href="#" class="btn btn-sm btn-icon btn-light-warning " data-bs-toggle="tooltip" data-bs-dismiss="click" data-bs-placement="top" title="Archivar">
                                                                        <i class="ki-duotone ki-sms fs-2">
                                                                            <span class="path1"></span>
                                                                            <span class="path2"></span>
                                                                        </i>
                                                                    </a>
                                                                    <!--end::Archive-->
                                                                    <!--begin::Delete-->
                                                                    <a href="#" class="btn btn-sm btn-icon btn-light-danger " data-bs-toggle="tooltip" data-bs-dismiss="click" data-bs-placement="top" title="Eliminar">
                                                                        <i class="ki-duotone ki-trash fs-2">
                                                                            <span class="path1"></span>
                                                                            <span class="path2"></span>
                                                                            <span class="path3"></span>
                                                                            <span class="path4"></span>
                                                                            <span class="path5"></span>
                                                                        </i>
                                                                    </a>
                                                                </div>

																<!--end::Heading-->
															</div>
															<!--begin::Badges-->

															<!--end::Badges-->
														</td>

													</tr>
                                                    <tr>
														<td class="ps-4">
															<div class="form-check form-check-sm form-check-custom form-check-solid mt-3">
																<input class="form-check-input" type="checkbox" value="1" />
															</div>
														</td>
														<td>
															<div class="text-dark gap-1 pt-2">
																<!--begin::Heading-->

																<a href="" class="text-primary" style="padding: 0 10px 0 0 ">
																	<span class="fw-bold">Digital PPV Customer Confirmation</span>

																    <br><span class="fw-semibold text-dark" style="font-size: 12px">15/04/2015 15:02:45</span>

                                                                </a><br>

                                                                <div style="text-align: right">
                                                                    <a href="#" class="btn btn-sm btn-icon btn-light-warning " data-bs-toggle="tooltip" data-bs-dismiss="click" data-bs-placement="top" title="Archivar">
                                                                        <i class="ki-duotone ki-sms fs-2">
                                                                            <span class="path1"></span>
                                                                            <span class="path2"></span>
                                                                        </i>
                                                                    </a>
                                                                    <!--end::Archive-->
                                                                    <!--begin::Delete-->
                                                                    <a href="#" class="btn btn-sm btn-icon btn-light-danger " data-bs-toggle="tooltip" data-bs-dismiss="click" data-bs-placement="top" title="Eliminar">
                                                                        <i class="ki-duotone ki-trash fs-2">
                                                                            <span class="path1"></span>
                                                                            <span class="path2"></span>
                                                                            <span class="path3"></span>
                                                                            <span class="path4"></span>
                                                                            <span class="path5"></span>
                                                                        </i>
                                                                    </a>
                                                                </div>

																<!--end::Heading-->
															</div>
															<!--begin::Badges-->

															<!--end::Badges-->
														</td>

													</tr>
                                                   <tr>
														<td class="ps-4">
															<div class="form-check form-check-sm form-check-custom form-check-solid mt-3">
																<input class="form-check-input" type="checkbox" value="1" />
															</div>
														</td>
														<td>
															<div class="text-dark gap-1 pt-2">
																<!--begin::Heading-->

																<a href="" class="text-primary" style="padding: 0 10px 0 0 ">
																	<span class="fw-bold">Digital PPV Customer Confirmation</span>

																    <br><span class="fw-semibold text-dark" style="font-size: 12px">15/04/2015 15:02:45</span>

                                                                </a><br>

                                                                <div style="text-align: right">
                                                                    <a href="#" class="btn btn-sm btn-icon btn-light-warning " data-bs-toggle="tooltip" data-bs-dismiss="click" data-bs-placement="top" title="Archivar">
                                                                        <i class="ki-duotone ki-sms fs-2">
                                                                            <span class="path1"></span>
                                                                            <span class="path2"></span>
                                                                        </i>
                                                                    </a>
                                                                    <!--end::Archive-->
                                                                    <!--begin::Delete-->
                                                                    <a href="#" class="btn btn-sm btn-icon btn-light-danger " data-bs-toggle="tooltip" data-bs-dismiss="click" data-bs-placement="top" title="Eliminar">
                                                                        <i class="ki-duotone ki-trash fs-2">
                                                                            <span class="path1"></span>
                                                                            <span class="path2"></span>
                                                                            <span class="path3"></span>
                                                                            <span class="path4"></span>
                                                                            <span class="path5"></span>
                                                                        </i>
                                                                    </a>
                                                                </div>

																<!--end::Heading-->
															</div>
															<!--begin::Badges-->

															<!--end::Badges-->
														</td>

													</tr>
												</tbody>
											</table>
											<!--end::Table-->
										</div>
									</div>
									<!--end::Card-->
								</div> --}}
                        <div class=" col-xl-6" style="border-left: 1px solid #c7c7c9;">
                            <!--begin::Card-->
                            <div class="card">
                                <div class="card-header align-items-center py-5 gap-5">
                                    <!--begin::Actions-->
                                    <div class="d-flex">
                                        <!--begin::Back-->
                                        <a href="../../demo2/dist/apps/inbox/listing.html"
                                            class="btn btn-sm btn-icon btn-clear btn-active-light-primary me-3"
                                            data-bs-toggle="tooltip" data-bs-placement="top" title="Back">
                                            <i class="ki-duotone ki-arrow-left fs-1 m-0">
                                                <span class="path1"></span>
                                                <span class="path2"></span>
                                            </i>
                                        </a>
                                        <!--end::Back-->
                                        <!--begin::Archive-->
                                        <a href="#"
                                            class="btn btn-sm btn-icon btn-light btn-active-light-primary me-2"
                                            data-bs-toggle="tooltip" data-bs-placement="top" title="Archive">
                                            <i class="ki-duotone ki-sms fs-2 m-0">
                                                <span class="path1"></span>
                                                <span class="path2"></span>
                                            </i>
                                        </a>
                                        <!--end::Archive-->
                                        <!--begin::Spam-->
                                        <a href="#"
                                            class="btn btn-sm btn-icon btn-light btn-active-light-primary me-2"
                                            data-bs-toggle="tooltip" data-bs-placement="top" title="Spam">
                                            <i class="ki-duotone ki-information fs-2 m-0">
                                                <span class="path1"></span>
                                                <span class="path2"></span>
                                                <span class="path3"></span>
                                            </i>
                                        </a>
                                        <!--end::Spam-->
                                        <!--begin::Delete-->
                                        <a href="#"
                                            class="btn btn-sm btn-icon btn-light btn-active-light-primary me-2"
                                            data-bs-toggle="tooltip" data-bs-placement="top" title="Delete">
                                            <i class="ki-duotone ki-trash fs-2 m-0">
                                                <span class="path1"></span>
                                                <span class="path2"></span>
                                                <span class="path3"></span>
                                                <span class="path4"></span>
                                                <span class="path5"></span>
                                            </i>
                                        </a>
                                        <!--end::Delete-->
                                        <!--begin::Mark as read-->
                                        <a href="#"
                                            class="btn btn-sm btn-icon btn-light btn-active-light-primary me-2"
                                            data-bs-toggle="tooltip" data-bs-placement="top" title="Mark as read">
                                            <i class="ki-duotone ki-copy fs-2 m-0"></i>
                                        </a>
                                        <!--end::Mark as read-->
                                        <!--begin::Move-->
                                        <a href="#" class="btn btn-sm btn-icon btn-light btn-active-light-primary"
                                            data-bs-toggle="tooltip" data-bs-placement="top" title="Move">
                                            <i class="ki-duotone ki-entrance-left fs-2 m-0">
                                                <span class="path1"></span>
                                                <span class="path2"></span>
                                            </i>
                                        </a>
                                        <!--end::Move-->
                                    </div>
                                    <!--end::Actions-->
                                    <!--begin::Pagination-->
                                    <div class="d-flex align-items-center">
                                        <!--begin::Pages info-->
                                        <span class="fw-semibold text-muted me-2">1 - 50 of 235</span>
                                        <!--end::Pages info-->
                                        <!--begin::Prev page-->
                                        <a href="#"
                                            class="btn btn-sm btn-icon btn-light btn-active-light-primary me-3"
                                            data-bs-toggle="tooltip" data-bs-placement="top" title="Previous message">
                                            <i class="ki-duotone ki-left fs-2 m-0"></i>
                                        </a>
                                        <!--end::Prev page-->
                                        <!--begin::Next page-->
                                        <a href="#"
                                            class="btn btn-sm btn-icon btn-light btn-active-light-primary me-2"
                                            data-bs-toggle="tooltip" data-bs-placement="top" title="Next message">
                                            <i class="ki-duotone ki-right fs-2 m-0"></i>
                                        </a>
                                        <!--end::Next page-->
                                        <!--begin::Settings menu-->
                                        <div>
                                            <a href="#"
                                                class="btn btn-sm btn-icon btn-light btn-active-light-primary me-2"
                                                data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end"
                                                data-bs-toggle="tooltip" data-bs-placement="top" title="Settings">
                                                <i class="ki-duotone ki-dots-square fs-2 m-0">
                                                    <span class="path1"></span>
                                                    <span class="path2"></span>
                                                    <span class="path3"></span>
                                                    <span class="path4"></span>
                                                </i>
                                            </a>
                                            <!--begin::Menu-->
                                            <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-600 menu-state-bg-light-primary fw-semibold fs-7 w-250px py-4"
                                                data-kt-menu="true">
                                                <!--begin::Menu item-->
                                                <div class="menu-item px-3">
                                                    <a href="#" class="menu-link px-3">
                                                        <i class="ki-duotone ki-element-11 fs-3 me-3">
                                                            <span class="path1"></span>
                                                            <span class="path2"></span>
                                                            <span class="path3"></span>
                                                            <span class="path4"></span>
                                                        </i>New Group</a>
                                                </div>
                                                <!--end::Menu item-->
                                                <!--begin::Menu item-->
                                                <div class="menu-item px-3">
                                                    <a href="#" class="menu-link px-3">
                                                        <i class="ki-duotone ki-badge fs-3 me-3">
                                                            <span class="path1"></span>
                                                            <span class="path2"></span>
                                                            <span class="path3"></span>
                                                            <span class="path4"></span>
                                                            <span class="path5"></span>
                                                        </i>Contacts</a>
                                                </div>
                                                <!--end::Menu item-->
                                                <!--begin::Menu item-->
                                                <div class="menu-item px-3">
                                                    <a href="#" class="menu-link px-3">
                                                        <i class="ki-duotone ki-people fs-3 me-3">
                                                            <span class="path1"></span>
                                                            <span class="path2"></span>
                                                            <span class="path3"></span>
                                                            <span class="path4"></span>
                                                            <span class="path5"></span>
                                                        </i>Groups
                                                        <span class="badge badge-light-primary ms-auto">new</span></a>
                                                </div>
                                                <!--end::Menu item-->
                                                <!--begin::Menu item-->
                                                <div class="menu-item px-3">
                                                    <a href="#" class="menu-link px-3">
                                                        <i class="ki-duotone ki-element-2 fs-3 me-3">
                                                            <span class="path1"></span>
                                                            <span class="path2"></span>
                                                        </i>Calls</a>
                                                </div>
                                                <!--end::Menu item-->
                                                <!--begin::Menu item-->
                                                <div class="menu-item px-3">
                                                    <a href="#" class="menu-link px-3">
                                                        <i class="ki-duotone ki-setting-2 fs-3 me-3">
                                                            <span class="path1"></span>
                                                            <span class="path2"></span>
                                                        </i>Settings</a>
                                                </div>
                                                <!--end::Menu item-->
                                                <div class="separator my-5"></div>
                                                <!--begin::Menu item-->
                                                <div class="menu-item px-3">
                                                    <a href="#" class="menu-link px-3">
                                                        <i class="ki-duotone ki-magnifier fs-3 me-3">
                                                            <span class="path1"></span>
                                                            <span class="path2"></span>
                                                        </i>Help</a>
                                                </div>
                                                <!--end::Menu item-->
                                                <!--begin::Menu item-->
                                                <div class="menu-item px-3">
                                                    <a href="#" class="menu-link px-3">
                                                        <i class="ki-duotone ki-shield-tick fs-3 me-3">
                                                            <span class="path1"></span>
                                                            <span class="path2"></span>
                                                        </i>Privacy
                                                        <span class="badge badge-light-danger ms-auto">5</span></a>
                                                </div>
                                                <!--end::Menu item-->
                                            </div>
                                            <!--end::Menu-->
                                        </div>
                                        <!--begin::Settings menu-->
                                        <!--begin::Toggle-->
                                        <a href="#"
                                            class="btn btn-sm btn-icon btn-color-primary btn-light btn-active-light-primary d-lg-none"
                                            data-bs-toggle="tooltip" data-bs-dismiss="click" data-bs-placement="top"
                                            title="Toggle inbox menu" id="kt_inbox_aside_toggle">
                                            <i class="ki-duotone ki-burger-menu-2 fs-3 m-0">
                                                <span class="path1"></span>
                                                <span class="path2"></span>
                                                <span class="path3"></span>
                                                <span class="path4"></span>
                                                <span class="path5"></span>
                                                <span class="path6"></span>
                                                <span class="path7"></span>
                                                <span class="path8"></span>
                                                <span class="path9"></span>
                                                <span class="path10"></span>
                                            </i>
                                        </a>
                                        <!--end::Toggle-->
                                    </div>
                                    <!--end::Pagination-->
                                </div>
                                <livewire:emitido.emitido-component />
                                {{-- <div class="card-body">
											<!--begin::Title-->
											<div class="d-flex flex-wrap gap-2 justify-content-between mb-8">
												<div class="d-flex align-items-center flex-wrap gap-2">
													<!--begin::Heading-->
													<h2 class="fw-semibold me-3 my-1">Trip Reminder. Thank you for flying with us!</h2>
													<!--begin::Heading-->
													<!--begin::Badges-->
													<span class="badge badge-light-primary my-1 me-2">inbox</span>
													<span class="badge badge-light-danger my-1">important</span>
													<!--end::Badges-->
												</div>
												<div class="d-flex">
													<!--begin::Sort-->
													<a href="#" class="btn btn-sm btn-icon btn-light btn-active-light-primary me-2" data-bs-toggle="tooltip" data-bs-placement="top" title="Sort">
														<i class="ki-duotone ki-arrow-up-down fs-2 m-0">
															<span class="path1"></span>
															<span class="path2"></span>
														</i>
													</a>
													<!--end::Sort-->
													<!--begin::Print-->
													<a href="#" class="btn btn-sm btn-icon btn-light btn-active-light-primary me-2" data-bs-toggle="tooltip" data-bs-placement="top" title="Print">
														<i class="ki-duotone ki-printer fs-2">
															<span class="path1"></span>
															<span class="path2"></span>
															<span class="path3"></span>
															<span class="path4"></span>
															<span class="path5"></span>
														</i>
													</a>
													<!--end::Print-->
												</div>
											</div>
											<!--end::Title-->
											<!--begin::Message accordion-->
											<div data-kt-inbox-message="message_wrapper">
												<!--begin::Message header-->
												<div class="d-flex flex-wrap gap-2 flex-stack cursor-pointer" data-kt-inbox-message="header">
													<!--begin::Author-->
													<div class="d-flex align-items-center">
														<!--begin::Avatar-->
														<div class="symbol symbol-50 me-4">
															<span class="symbol-label" style="background-image:url(assets/media/avatars/300-6.jpg);"></span>
														</div>
														<!--end::Avatar-->
														<div class="pe-5">
															<!--begin::Author details-->
															<div class="d-flex align-items-center flex-wrap gap-1">
																<a href="#" class="fw-bold text-dark text-hover-primary">Emma Smith</a>
																<i class="ki-duotone ki-abstract-8 fs-7 text-success mx-3">
																	<span class="path1"></span>
																	<span class="path2"></span>
																</i>
																<span class="text-muted fw-bold">1 day ago</span>
															</div>
															<!--end::Author details-->
															<!--begin::Message details-->
															<div data-kt-inbox-message="details">
																<span class="text-muted fw-semibold">to me</span>
																<!--begin::Menu toggle-->
																<a href="#" class="me-1" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-start">
																	<i class="ki-duotone ki-down fs-5 m-0"></i>
																</a>
																<!--end::Menu toggle-->
																<!--begin::Menu-->
																<div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-600 menu-state-bg-light-primary fw-semibold fs-7 w-300px p-4" data-kt-menu="true">
																	<!--begin::Table-->
																	<table class="table mb-0">
																		<tbody>
																			<tr>
																				<td class="w-75px text-muted">From</td>
																				<td>Emma Bold</td>
																			</tr>
																			<tr>
																				<td class="text-muted">Date</td>
																				<td>24 Jun 2023, 11:30 am</td>
																			</tr>
																			<tr>
																				<td class="text-muted">Subject</td>
																				<td>Trip Reminder. Thank you for flying with us!</td>
																			</tr>
																			<tr>
																				<td class="text-muted">Reply-to</td>
																				<td>emma@intenso.com</td>
																			</tr>
																		</tbody>
																	</table>
																</div>
																<!--end::Menu-->
															</div>
															<!--end::Message details-->
															<!--begin::Preview message-->
															<div class="text-muted fw-semibold mw-450px d-none" data-kt-inbox-message="preview">With resrpect, i must disagree with Mr.Zinsser. We all know the most part of important part....</div>
															<!--end::Preview message-->
														</div>
													</div>
													<!--end::Author-->
													<!--begin::Actions-->
													<div class="d-flex align-items-center flex-wrap gap-2">
														<!--begin::Date-->
														<span class="fw-semibold text-muted text-end me-3">25 Jul 2023, 9:23 pm</span>
														<!--end::Date-->
														<div class="d-flex">
															<!--begin::Star-->
															<a href="#" class="btn btn-sm btn-icon btn-clear btn-active-light-primary me-3" data-bs-toggle="tooltip" data-bs-placement="top" title="Star">
																<i class="ki-duotone ki-star fs-2 m-0"></i>
															</a>
															<!--end::Star-->
															<!--begin::Mark as important-->
															<a href="#" class="btn btn-sm btn-icon btn-clear btn-active-light-primary me-3" data-bs-toggle="tooltip" data-bs-placement="top" title="Mark as important">
																<i class="ki-duotone ki-save-2 fs-2 m-0">
																	<span class="path1"></span>
																	<span class="path2"></span>
																</i>
															</a>
															<!--end::Mark as important-->
															<!--begin::Reply-->
															<a href="#" class="btn btn-sm btn-icon btn-clear btn-active-light-primary me-3" data-bs-toggle="tooltip" data-bs-placement="top" title="Reply">
																<i class="ki-duotone ki-message-edit fs-2 m-0">
																	<span class="path1"></span>
																	<span class="path2"></span>
																</i>
															</a>
															<!--end::Reply-->
															<!--begin::Settings-->
															<a href="#" class="btn btn-sm btn-icon btn-clear btn-active-light-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="Settings">
																<i class="ki-duotone ki-dots-square-vertical fs-2 m-0">
																	<span class="path1"></span>
																	<span class="path2"></span>
																	<span class="path3"></span>
																	<span class="path4"></span>
																</i>
															</a>
															<!--end::Settings-->
														</div>
													</div>
													<!--end::Actions-->
												</div>
												<!--end::Message header-->
												<!--begin::Message content-->
												<div class="collapse fade show" data-kt-inbox-message="message">
													<div class="py-5">
														<p>Hi Bob,</p>
														<p>With resrpect, i must disagree with Mr.Zinsser. We all know the most part of important part of any article is the title.Without a compelleing title, your reader won't even get to the first sentence.After the title, however, the first few sentences of your article are certainly the most important part.</p>
														<p>Jornalists call this critical, introductory section the "Lede," and when bridge properly executed, it's the that carries your reader from an headine try at attention-grabbing to the body of your blog post, if you want to get it right on of these 10 clever ways to omen your next blog posr with a bang</p>
														<p>Best regards,</p>
														<p class="mb-0">Jason Muller</p>
													</div>
												</div>
												<!--end::Message content-->
											</div>
											<!--end::Message accordion-->
											<div class="separator my-6"></div>
											<!--begin::Message accordion-->
											<div data-kt-inbox-message="message_wrapper">
												<!--begin::Message header-->
												<div class="d-flex flex-wrap gap-2 flex-stack cursor-pointer" data-kt-inbox-message="header">
													<!--begin::Author-->
													<div class="d-flex align-items-center">
														<!--begin::Avatar-->
														<div class="symbol symbol-50 me-4">
															<span class="symbol-label" style="background-image:url(assets/media/avatars/300-1.jpg);"></span>
														</div>
														<!--end::Avatar-->
														<div class="pe-5">
															<!--begin::Author details-->
															<div class="d-flex align-items-center flex-wrap gap-1">
																<a href="#" class="fw-bold text-dark text-hover-primary">Max Smith</a>
																<i class="ki-duotone ki-abstract-8 fs-7 text-success mx-3">
																	<span class="path1"></span>
																	<span class="path2"></span>
																</i>
																<span class="text-muted fw-bold">2 days ago</span>
															</div>
															<!--end::Author details-->
															<!--begin::Message details-->
															<div class="d-none" data-kt-inbox-message="details">
																<span class="text-muted fw-semibold">to me</span>
																<!--begin::Menu toggle-->
																<a href="#" class="me-1" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-start">
																	<i class="ki-duotone ki-down fs-5 m-0"></i>
																</a>
																<!--end::Menu toggle-->
																<!--begin::Menu-->
																<div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-600 menu-state-bg-light-primary fw-semibold fs-7 w-300px p-4" data-kt-menu="true">
																	<!--begin::Table-->
																	<table class="table mb-0">
																		<tbody>
																			<tr>
																				<td class="w-75px text-muted">From</td>
																				<td>Emma Bold</td>
																			</tr>
																			<tr>
																				<td class="text-muted">Date</td>
																				<td>25 Oct 2023, 9:23 pm</td>
																			</tr>
																			<tr>
																				<td class="text-muted">Subject</td>
																				<td>Trip Reminder. Thank you for flying with us!</td>
																			</tr>
																			<tr>
																				<td class="text-muted">Reply-to</td>
																				<td>emma@intenso.com</td>
																			</tr>
																		</tbody>
																	</table>
																</div>
																<!--end::Menu-->
															</div>
															<!--end::Message details-->
															<!--begin::Preview message-->
															<div class="text-muted fw-semibold mw-450px" data-kt-inbox-message="preview">Jornalists call this critical, introductory section the "Lede," and when bridge properly executed....</div>
															<!--end::Preview message-->
														</div>
													</div>
													<!--end::Author-->
													<!--begin::Actions-->
													<div class="d-flex align-items-center flex-wrap gap-2">
														<!--begin::Date-->
														<span class="fw-semibold text-muted text-end me-3">21 Feb 2023, 9:23 pm</span>
														<!--end::Date-->
														<div class="d-flex">
															<!--begin::Star-->
															<a href="#" class="btn btn-sm btn-icon btn-clear btn-active-light-primary me-3" data-bs-toggle="tooltip" data-bs-placement="top" title="Star">
																<i class="ki-duotone ki-star fs-2 text-warning m-0"></i>
															</a>
															<!--end::Star-->
															<!--begin::Mark as important-->
															<a href="#" class="btn btn-sm btn-icon btn-clear btn-active-light-primary me-3" data-bs-toggle="tooltip" data-bs-placement="top" title="Mark as important">
																<i class="ki-duotone ki-save-2 fs-2 m-0">
																	<span class="path1"></span>
																	<span class="path2"></span>
																</i>
															</a>
															<!--end::Mark as important-->
															<!--begin::Reply-->
															<a href="#" class="btn btn-sm btn-icon btn-clear btn-active-light-primary me-3" data-bs-toggle="tooltip" data-bs-placement="top" title="Reply">
																<i class="ki-duotone ki-message-edit fs-2 m-0">
																	<span class="path1"></span>
																	<span class="path2"></span>
																</i>
															</a>
															<!--end::Reply-->
															<!--begin::Settings-->
															<a href="#" class="btn btn-sm btn-icon btn-clear btn-active-light-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="Settings">
																<i class="ki-duotone ki-dots-square-vertical fs-2 m-0">
																	<span class="path1"></span>
																	<span class="path2"></span>
																	<span class="path3"></span>
																	<span class="path4"></span>
																</i>
															</a>
															<!--end::Settings-->
														</div>
													</div>
													<!--end::Actions-->
												</div>
												<!--end::Message header-->
												<!--begin::Message content-->
												<div class="collapse fade" data-kt-inbox-message="message">
													<div class="py-5">
														<p>Hi Bob,</p>
														<p>With resrpect, i must disagree with Mr.Zinsser. We all know the most part of important part of any article is the title.Without a compelleing title, your reader won't even get to the first sentence.After the title, however, the first few sentences of your article are certainly the most important part.</p>
														<p>Jornalists call this critical, introductory section the "Lede," and when bridge properly executed, it's the that carries your reader from an headine try at attention-grabbing to the body of your blog post, if you want to get it right on of these 10 clever ways to omen your next blog posr with a bang</p>
														<p>Best regards,</p>
														<p class="mb-0">Jason Muller</p>
													</div>
												</div>
												<!--end::Message content-->
											</div>
											<!--end::Message accordion-->
											<div class="separator my-6"></div>
											<!--begin::Message accordion-->
											<div data-kt-inbox-message="message_wrapper">
												<!--begin::Message header-->
												<div class="d-flex flex-wrap gap-2 flex-stack cursor-pointer" data-kt-inbox-message="header">
													<!--begin::Author-->
													<div class="d-flex align-items-center">
														<!--begin::Avatar-->
														<div class="symbol symbol-50 me-4">
															<span class="symbol-label" style="background-image:url(assets/media/avatars/300-5.jpg);"></span>
														</div>
														<!--end::Avatar-->
														<div class="pe-5">
															<!--begin::Author details-->
															<div class="d-flex align-items-center flex-wrap gap-1">
																<a href="#" class="fw-bold text-dark text-hover-primary">Sean Bean</a>
																<i class="ki-duotone ki-abstract-8 fs-7 text-success mx-3">
																	<span class="path1"></span>
																	<span class="path2"></span>
																</i>
																<span class="text-muted fw-bold">3 days ago</span>
															</div>
															<!--end::Author details-->
															<!--begin::Message details-->
															<div class="d-none" data-kt-inbox-message="details">
																<span class="text-muted fw-semibold">to me</span>
																<!--begin::Menu toggle-->
																<a href="#" class="me-1" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-start">
																	<i class="ki-duotone ki-down fs-5 m-0"></i>
																</a>
																<!--end::Menu toggle-->
																<!--begin::Menu-->
																<div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-600 menu-state-bg-light-primary fw-semibold fs-7 w-300px p-4" data-kt-menu="true">
																	<!--begin::Table-->
																	<table class="table mb-0">
																		<tbody>
																			<tr>
																				<td class="w-75px text-muted">From</td>
																				<td>Emma Bold</td>
																			</tr>
																			<tr>
																				<td class="text-muted">Date</td>
																				<td>20 Dec 2023, 6:05 pm</td>
																			</tr>
																			<tr>
																				<td class="text-muted">Subject</td>
																				<td>Trip Reminder. Thank you for flying with us!</td>
																			</tr>
																			<tr>
																				<td class="text-muted">Reply-to</td>
																				<td>emma@intenso.com</td>
																			</tr>
																		</tbody>
																	</table>
																</div>
																<!--end::Menu-->
															</div>
															<!--end::Message details-->
															<!--begin::Preview message-->
															<div class="text-muted fw-semibold mw-450px" data-kt-inbox-message="preview">Jornalists call this critical, introductory section the "Lede," and when bridge properly executed....</div>
															<!--end::Preview message-->
														</div>
													</div>
													<!--end::Author-->
													<!--begin::Actions-->
													<div class="d-flex align-items-center flex-wrap gap-2">
														<!--begin::Date-->
														<span class="fw-semibold text-muted text-end me-3">25 Oct 2023, 11:30 am</span>
														<!--end::Date-->
														<div class="d-flex">
															<!--begin::Star-->
															<a href="#" class="btn btn-sm btn-icon btn-clear btn-active-light-primary me-3" data-bs-toggle="tooltip" data-bs-placement="top" title="Star">
																<i class="ki-duotone ki-star fs-2 m-0"></i>
															</a>
															<!--end::Star-->
															<!--begin::Mark as important-->
															<a href="#" class="btn btn-sm btn-icon btn-clear btn-active-light-primary me-3" data-bs-toggle="tooltip" data-bs-placement="top" title="Mark as important">
																<i class="ki-duotone ki-save-2 fs-2 m-0">
																	<span class="path1"></span>
																	<span class="path2"></span>
																</i>
															</a>
															<!--end::Mark as important-->
															<!--begin::Reply-->
															<a href="#" class="btn btn-sm btn-icon btn-clear btn-active-light-primary me-3" data-bs-toggle="tooltip" data-bs-placement="top" title="Reply">
																<i class="ki-duotone ki-message-edit fs-2 m-0">
																	<span class="path1"></span>
																	<span class="path2"></span>
																</i>
															</a>
															<!--end::Reply-->
															<!--begin::Settings-->
															<a href="#" class="btn btn-sm btn-icon btn-clear btn-active-light-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="Settings">
																<i class="ki-duotone ki-dots-square-vertical fs-2 m-0">
																	<span class="path1"></span>
																	<span class="path2"></span>
																	<span class="path3"></span>
																	<span class="path4"></span>
																</i>
															</a>
															<!--end::Settings-->
														</div>
													</div>
													<!--end::Actions-->
												</div>
												<!--end::Message header-->
												<!--begin::Message content-->
												<div class="collapse fade" data-kt-inbox-message="message">
													<div class="py-5">
														<p>Hi Bob,</p>
														<p>With resrpect, i must disagree with Mr.Zinsser. We all know the most part of important part of any article is the title.Without a compelleing title, your reader won't even get to the first sentence.After the title, however, the first few sentences of your article are certainly the most important part.</p>
														<p>Jornalists call this critical, introductory section the "Lede," and when bridge properly executed, it's the that carries your reader from an headine try at attention-grabbing to the body of your blog post, if you want to get it right on of these 10 clever ways to omen your next blog posr with a bang</p>
														<p>Best regards,</p>
														<p class="mb-0">Jason Muller</p>
													</div>
												</div>
												<!--end::Message content-->
											</div>
											<!--end::Message accordion-->
											<!--begin::Form-->
											<form id="kt_inbox_reply_form" class="rounded border mt-10">
												<!--begin::Body-->
												<div class="d-block">
													<!--begin::To-->
													<div class="d-flex align-items-center border-bottom px-8 min-h-50px">
														<!--begin::Label-->
														<div class="text-dark fw-bold w-75px">To:</div>
														<!--end::Label-->
														<!--begin::Input-->
														<input type="text" class="form-control border-0" name="compose_to" value="e.smith@kpmg.com.au, max@kt.com, sean@dellito.com" data-kt-inbox-form="tagify" />
														<!--end::Input-->
														<!--begin::CC & BCC buttons-->
														<div class="ms-auto w-75px text-end">
															<span class="text-muted fs-bold cursor-pointer text-hover-primary me-2" data-kt-inbox-form="cc_button">Cc</span>
															<span class="text-muted fs-bold cursor-pointer text-hover-primary" data-kt-inbox-form="bcc_button">Bcc</span>
														</div>
														<!--end::CC & BCC buttons-->
													</div>
													<!--end::To-->
													<!--begin::CC-->
													<div class="d-none align-items-center border-bottom ps-8 pe-5 min-h-50px" data-kt-inbox-form="cc">
														<!--begin::Label-->
														<div class="text-dark fw-bold w-75px">Cc:</div>
														<!--end::Label-->
														<!--begin::Input-->
														<input type="text" class="form-control border-0" name="compose_cc" value="" data-kt-inbox-form="tagify" />
														<!--end::Input-->
														<!--begin::Close-->
														<span class="btn btn-clean btn-xs btn-icon" data-kt-inbox-form="cc_close">
															<i class="ki-duotone ki-cross fs-5">
																<span class="path1"></span>
																<span class="path2"></span>
															</i>
														</span>
														<!--end::Close-->
													</div>
													<!--end::CC-->
													<!--begin::BCC-->
													<div class="d-none align-items-center border-bottom inbox-to-bcc ps-8 pe-5 min-h-50px" data-kt-inbox-form="bcc">
														<!--begin::Label-->
														<div class="text-dark fw-bold w-75px">Bcc:</div>
														<!--end::Label-->
														<!--begin::Input-->
														<input type="text" class="form-control border-0" name="compose_bcc" value="" data-kt-inbox-form="tagify" />
														<!--end::Input-->
														<!--begin::Close-->
														<span class="btn btn-clean btn-xs btn-icon" data-kt-inbox-form="bcc_close">
															<i class="ki-duotone ki-cross fs-5">
																<span class="path1"></span>
																<span class="path2"></span>
															</i>
														</span>
														<!--end::Close-->
													</div>
													<!--end::BCC-->
													<!--begin::Subject-->
													<div class="border-bottom">
														<input class="form-control border-0 px-8 min-h-45px" name="compose_subject" placeholder="Subject" />
													</div>
													<!--end::Subject-->
													<!--begin::Message-->
													<div id="kt_inbox_form_editor" class="border-0 h-250px px-3"></div>
													<!--end::Message-->
													<!--begin::Attachments-->
													<div class="dropzone dropzone-queue px-8 py-4" id="kt_inbox_reply_attachments" data-kt-inbox-form="dropzone">
														<div class="dropzone-items">
															<div class="dropzone-item" style="display:none">
																<!--begin::Dropzone filename-->
																<div class="dropzone-file">
																	<div class="dropzone-filename" title="some_image_file_name.jpg">
																		<span data-dz-name="">some_image_file_name.jpg</span>
																		<strong>(
																		<span data-dz-size="">340kb</span>)</strong>
																	</div>
																	<div class="dropzone-error" data-dz-errormessage=""></div>
																</div>
																<!--end::Dropzone filename-->
																<!--begin::Dropzone progress-->
																<div class="dropzone-progress">
																	<div class="progress">
																		<div class="progress-bar bg-primary" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" data-dz-uploadprogress=""></div>
																	</div>
																</div>
																<!--end::Dropzone progress-->
																<!--begin::Dropzone toolbar-->
																<div class="dropzone-toolbar">
																	<span class="dropzone-delete" data-dz-remove="">
																		<i class="ki-duotone ki-cross fs-6">
																			<span class="path1"></span>
																			<span class="path2"></span>
																		</i>
																	</span>
																</div>
																<!--end::Dropzone toolbar-->
															</div>
														</div>
													</div>
													<!--end::Attachments-->
												</div>
												<!--end::Body-->
												<!--begin::Footer-->
												<div class="d-flex flex-stack flex-wrap gap-2 py-5 ps-8 pe-5 border-top">
													<!--begin::Actions-->
													<div class="d-flex align-items-center me-3">
														<!--begin::Send-->
														<div class="btn-group me-4">
															<!--begin::Submit-->
															<span class="btn btn-primary fs-bold px-6" data-kt-inbox-form="send">
																<span class="indicator-label">Send</span>
																<span class="indicator-progress">Please wait...
																<span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
															</span>
															<!--end::Submit-->
															<!--begin::Send options-->
															<span class="btn btn-primary btn-icon fs-bold" role="button">
																<span class="btn btn-icon" data-kt-menu-trigger="click" data-kt-menu-placement="top-start">
																	<i class="ki-duotone ki-down fs-2 m-0"></i>
																</span>
																<!--begin::Menu-->
																<div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-600 menu-state-bg-light-primary fw-semibold fs-7 w-150px py-4" data-kt-menu="true">
																	<!--begin::Menu item-->
																	<div class="menu-item px-3">
																		<a href="#" class="menu-link px-3">Schedule send</a>
																	</div>
																	<!--end::Menu item-->
																	<!--begin::Menu item-->
																	<div class="menu-item px-3">
																		<a href="#" class="menu-link px-3">Save & archive</a>
																	</div>
																	<!--end::Menu item-->
																	<!--begin::Menu item-->
																	<div class="menu-item px-3">
																		<a href="#" class="menu-link px-3">Cancel</a>
																	</div>
																	<!--end::Menu item-->
																</div>
																<!--end::Menu-->
															</span>
															<!--end::Send options-->
														</div>
														<!--end::Send-->
														<!--begin::Upload attachement-->
														<span class="btn btn-icon btn-sm btn-clean btn-active-light-primary me-2" id="kt_inbox_reply_attachments_select" data-kt-inbox-form="dropzone_upload">
															<i class="ki-duotone ki-paper-clip fs-2 m-0"></i>
														</span>
														<!--end::Upload attachement-->
														<!--begin::Pin-->
														<span class="btn btn-icon btn-sm btn-clean btn-active-light-primary">
															<i class="ki-duotone ki-geolocation fs-2 m-0">
																<span class="path1"></span>
																<span class="path2"></span>
															</i>
														</span>
														<!--end::Pin-->
													</div>
													<!--end::Actions-->
													<!--begin::Toolbar-->
													<div class="d-flex align-items-center">
														<!--begin::More actions-->
														<span class="btn btn-icon btn-sm btn-clean btn-active-light-primary me-2" data-toggle="tooltip" title="More actions">
															<i class="ki-duotone ki-setting-2 fs-2">
																<span class="path1"></span>
																<span class="path2"></span>
															</i>
														</span>
														<!--end::More actions-->
														<!--begin::Dismiss reply-->
														<span class="btn btn-icon btn-sm btn-clean btn-active-light-primary" data-inbox="dismiss" data-toggle="tooltip" title="Dismiss reply">
															<i class="ki-duotone ki-trash fs-2">
																<span class="path1"></span>
																<span class="path2"></span>
																<span class="path3"></span>
																<span class="path4"></span>
																<span class="path5"></span>
															</i>
														</span>
														<!--end::Dismiss reply-->
													</div>
													<!--end::Toolbar-->
												</div>
												<!--end::Footer-->
											</form>
											<!--end::Form-->
										</div> --}}
                            </div>
                            <!--end::Card-->
                        </div>
                    </div>



                    <!--end::Table-->
                </div>
                <!--end::Card body-->
            </div>
            <!--end::Products-->
        </div>
        <!--end::Post-->
    </div>
@endsection
